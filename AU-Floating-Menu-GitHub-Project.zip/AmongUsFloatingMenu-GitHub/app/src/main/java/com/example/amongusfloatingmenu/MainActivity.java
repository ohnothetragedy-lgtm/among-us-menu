package com.example.amongusfloatingmenu;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 44;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 48, 36, 36);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(16, 19, 27));

        TextView title = new TextView(this);
        title.setText("AMONG US HOST TOOLS");
        title.setTextColor(Color.rgb(105, 224, 181));
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 20, 0, 16);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView info = new TextView(this);
        info.setText("Floating companion menu for your Galaxy Tab A8.\n\n"
                + "This prototype displays a draggable button above other apps. "
                + "Its switches are visual demos only: it does not connect to Among Us, "
                + "detect the real host, read game memory, track players, or reveal hidden roles.");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(15);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 12, 0, 28);
        root.addView(info);

        Button start = new Button(this);
        start.setText("Enable floating menu");
        start.setAllCaps(false);
        start.setOnClickListener(v -> enableOverlay());
        root.addView(start, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button stop = new Button(this);
        stop.setText("Stop floating menu");
        stop.setAllCaps(false);
        stop.setOnClickListener(v -> stopService(new Intent(this, FloatingMenuService.class)));
        root.addView(stop, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private void enableOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(permission, REQUEST_OVERLAY);
            return;
        }
        startFloatingService();
    }

    private void startFloatingService() {
        Intent service = new Intent(this, FloatingMenuService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(service);
        } else {
            startService(service);
        }
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) {
            startFloatingService();
        }
    }
}
