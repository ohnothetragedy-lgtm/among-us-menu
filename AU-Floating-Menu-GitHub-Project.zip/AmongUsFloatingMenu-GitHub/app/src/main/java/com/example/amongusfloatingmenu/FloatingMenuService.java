package com.example.amongusfloatingmenu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.CompoundButton;
import android.widget.Switch;

public class FloatingMenuService extends Service {
    private static final String CHANNEL = "among_us_floating_menu";
    private WindowManager wm;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private boolean expanded = false;
    private boolean hostDemo = false;

    private final int bg = Color.rgb(16, 19, 27);
    private final int card = Color.rgb(27, 33, 48);
    private final int mint = Color.rgb(105, 224, 181);

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(7, buildNotification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "Among Us Floating Menu", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the floating companion menu running");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL)
                    .setContentTitle("Among Us Host Tools")
                    .setContentText("Floating demo menu is active")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .build();
        }
        return new Notification.Builder(this)
                .setContentTitle("Among Us Host Tools")
                .setContentText("Floating demo menu is active")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build();
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(1, Color.rgb(54, 65, 84));
        return d;
    }

    private WindowManager.LayoutParams overlayParams(int width, int height, int gravity) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(12, 8, 12, 8);
        return t;
    }

    private void showBubble() {
        bubble = new TextView(this);
        ((TextView) bubble).setText("AU");
        ((TextView) bubble).setTextColor(bg);
        ((TextView) bubble).setTextSize(15);
        ((TextView) bubble).setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        ((TextView) bubble).setGravity(Gravity.CENTER);
        bubble.setBackground(rounded(mint, 100));
        bubbleParams = overlayParams(58, 58, Gravity.TOP | Gravity.START);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = 18;
        bubbleParams.y = 220;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = bubbleParams.x; startY = bubbleParams.y; moved = false;
                    return true;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int dx = (int)(e.getRawX() - downX);
                    int dy = (int)(e.getRawY() - downY);
                    if (Math.abs(dx) + Math.abs(dy) > 8) moved = true;
                    bubbleParams.x = startX + dx; bubbleParams.y = startY + dy;
                    wm.updateViewLayout(bubble, bubbleParams);
                    return true;
                } else if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) togglePanel();
                    return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleParams);
    }

    private void togglePanel() {
        if (expanded) {
            if (panel != null) { wm.removeView(panel); panel = null; }
            expanded = false;
        } else {
            showPanel();
            expanded = true;
        }
    }

    private void addToggle(LinearLayout parent, String label, boolean enabled, boolean locked,
                           CompoundButton.OnCheckedChangeListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 13, Color.WHITE, false);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(enabled);
        sw.setEnabled(!locked);
        sw.setOnCheckedChangeListener(listener);
        row.addView(sw);
        parent.addView(row);
    }

    private void showPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14, 12, 14, 12);
        box.setBackground(rounded(card, 28));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("AMONG US  ·  HOST TOOLS", 14, mint, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = text("✕", 18, Color.WHITE, true);
        close.setOnClickListener(v -> togglePanel());
        header.addView(close);
        box.addView(header);

        TextView status = text(hostDemo ? "DEMO HOST MODE ON" : "HOST MODE OFF",
                11, hostDemo ? mint : Color.rgb(255, 177, 185), true);
        box.addView(status);

        addToggle(box, "Enable demo host mode", hostDemo, false,
                (button, checked) -> {
                    hostDemo = checked;
                    togglePanel();
                    togglePanel();
                });
        addToggle(box, "ESP / highlighting preview", false, !hostDemo, (b, c) -> {});
        addToggle(box, "Player tracers preview", false, !hostDemo, (b, c) -> {});
        addToggle(box, "Player list (sample only)", true, false, (b, c) -> {});
        addToggle(box, "Consensual role display demo", false, !hostDemo, (b, c) -> {});

        TextView disclaimer = text("DEMO ONLY — does not connect to Among Us or read game data.",
                10, Color.LTGRAY, false);
        box.addView(disclaimer);

        TextView stop = text("STOP FLOATING MENU", 11, mint, true);
        stop.setGravity(Gravity.CENTER);
        stop.setOnClickListener(v -> stopSelf());
        box.addView(stop);

        panelParams = overlayParams(300, -2, Gravity.TOP | Gravity.START);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = 16;
        panelParams.y = 285;
        panel = box;
        wm.addView(panel, panelParams);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (wm != null) {
            if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} }
            if (bubble != null) { try { wm.removeView(bubble); } catch (Exception ignored) {} }
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
