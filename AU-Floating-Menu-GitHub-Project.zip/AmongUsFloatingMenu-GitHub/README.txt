AMONG US FLOATING MENU — GITHUB BUILD PROJECT

This is the same Java floating-overlay demo, with a GitHub Actions workflow added.

BUILD ON GITHUB (NO PC REQUIRED):
1. Create a new repository on https://github.com/new. Give it a name such as AmongUsFloatingMenu. Set it to Private if you prefer. Do not add a README, license, or .gitignore (this ZIP already contains the project files).
2. Extract this ZIP on your Android tablet using the built-in My Files app. Open the extracted folder.
3. In the GitHub repository, choose Add file > Upload files. Upload the CONTENTS of the extracted folder, including the .github folder. If the file picker hides dot-folders, enable showing hidden files or use GitHub's web editor to create .github/workflows/android-apk.yml with the contents of that file.
4. Commit the uploaded files to the main branch.
5. Open the repository's Actions tab. Choose "Build floating menu APK" if prompted, then select Run workflow. A push to main also starts the build automatically.
6. When the run finishes successfully, open it, scroll to Artifacts, and download AmongUsFloatingMenu-debug-apk. Extract it and install app-debug.apk on the tablet.

NOTES:
- This workflow compiles the Android project using GitHub-hosted build machines; no Android Studio or PC is required.
- GitHub may ask you to verify your email or enable Actions for the repository.
- This debug APK is unsigned for Play Store distribution but can be installed directly after allowing your browser/file manager to install unknown apps.
- The app is a floating companion-menu DEMO only. It does not connect to Among Us, verify host status, read game data, track real players, or reveal hidden roles.
